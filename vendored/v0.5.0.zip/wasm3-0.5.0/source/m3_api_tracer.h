//
//  m3_api_tracer.h
//
//  Created by Volodymyr Shymanskyy on 02/18/20.
//  Copyright © 2020 Volodymyr Shymanskyy. All rights reserved.
//

#ifndef m3_api_tracer_h
#define m3_api_tracer_h

#include "m3_core.h"

d_m3BeginExternC

M3Result    m3_LinkTracer       (IM3Module io_module);

d_m3EndExternC

#endif // m3_api_tracer_h
