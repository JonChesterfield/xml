#warning "Using m3_api_defs.h is deprecated. Just include wasm3.h"

