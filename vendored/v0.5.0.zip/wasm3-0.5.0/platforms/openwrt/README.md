# wasm3 for OpenWrt

You can find `wasm3` package and build instructions here:

https://github.com/wasm3/wasm3-openwrt-packages

