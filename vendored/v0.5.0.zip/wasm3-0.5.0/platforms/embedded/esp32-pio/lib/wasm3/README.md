This is a placeholder for the wasm3 PIO library.

At the moment it simply adds the source code as a symlink, and sets some build flags.
