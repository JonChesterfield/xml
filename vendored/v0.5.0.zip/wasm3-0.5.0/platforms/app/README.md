This is the main file for Linux, Windows, Mac OS, OpenWRT builds
