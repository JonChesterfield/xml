# pywasm3

Python binding for Wasm3, the fastest WebAssembly interpreter.

## Moved to https://github.com/wasm3/pywasm3
