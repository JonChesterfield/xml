# CoreMark 1.0

See https://github.com/wasm3/wasm3-coremark
