# Code of Conduct

uvwasi is committed to upholding the Node.js Code of Conduct.

The Node.js Code of Conduct document can be found at
https://github.com/nodejs/admin/blob/master/CODE_OF_CONDUCT.md
